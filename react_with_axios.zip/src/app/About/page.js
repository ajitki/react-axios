import React from 'react'

const about = () => {
  return (
    <div>About</div>
  )
}

export default about;