import React from "react";

const Career = ()=>{
    return(
    <h2>Career</h2>    
    );
}
export default Career;