import React from 'react'

const info = () => {
  return (
    <div>Info</div>
  )
}

export default info;